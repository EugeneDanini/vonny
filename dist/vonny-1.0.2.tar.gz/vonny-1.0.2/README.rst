#####
vonny
#####
Text vonnytization
------------------
(supports cyrillic and latin)

Installation and usage
----------------------


.. code-block:: bash

    $ pip install vonny

.. code-block:: bash

    $ pip install dist/vonny-1.0.0.tar.gz


.. code-block:: python

    >>> from vonny.utils import vonnytize
    >>> print(vonnytize('Hello, World!'))
    Hllo, Wrld!