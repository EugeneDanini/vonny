Vonny package
Text vonnytization
