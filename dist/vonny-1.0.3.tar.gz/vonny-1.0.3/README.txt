Vonny package
Text vonnytization (supports cyrillic and latin)

Installation:
$ pip install vonny
or
$ pip install dist/vonny-1.0.2.tar.gz

Usage:
>>> from vonny.utils import vonnytize
>>> print(vonnytize('Hello, World!'))
Hllo, Wrld!
